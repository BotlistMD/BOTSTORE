<p align="center">
<img src="https://a.uguu.se/JdgoBrk.jpg" alt="Hinata-Md" width="100"/>


</p>
<p align="center">
<a href="#"><img title="HINATA HYUGA" src="https://img.shields.io/badge/HINATA HYUGA-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/riychdwayne/followers"><img title="Followers" src="https://img.shields.io/github/followers/riychdwayne?color=red&style=flat-square"></a>
<a href="https://github.com/riychdwayne/Hinata-Md/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/riychdwayne/Hinata-Md?color=blue&style=flat-square"></a>
<a href="https://github.com/riychdwayne/Hinata-Md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/riychdwayne/Hinata-Md?color=red&style=flat-square"></a>
<a href="https://github.com/riychdwayne/Hinata-Md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/riychdwayne/Hinata-Md?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/riychdwayne/Hinata-Md"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/riychdwayne/Hinata-Md/"><img title="Size" src="https://img.shields.io/github/repo-size/riychdwayne/Hinata-Md?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Friychdwayne%2FHinata-Md&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/riychdwayne/Hinata-Md/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>

<p align="center">
  <a href="https://github.com/riychdwayne/Hinata-Md#requirements">Requirements</a> •
  <a href="https://github.com/riychdwayne/Hinata-Md#instalasi">Installation</a> •
  <a href="https://github.com/riychdwayne/Hinata-Md#thanks-to">Thanks to</a> •
  <a href="https://github.com/riychdwayne/Hinata-Md#Official-Group"> Official Group Bot</a> •
  <a href="https://github.com/riychdwayne/Hinata-Md#donate">Donate</a>
</p>
</div>


---

## Bugs and Tester
* Jika kamu menemukan bug jangan lupa buka Issues
* Info Lebih Lanjut, Chat [owner-hinata](https://wa.me/6281575886399)

# Requirements
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip) (for sticker command)

# Instalasi
## Heroku Buildpack
```bash
heroku/nodejs
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```
## For Termux
```ts
termux-setup-storage
apt update && apt upgrade
pkg install nodejs git ffmpeg libwebp imagemagick
git clone https://github.com/riychdwayne/Hinata-Md.git
cd Hinata-Md
pkg install yarn
yarn
npm start
```

## ```HOW TO DEPLOY```

[`Click Here For Tutorial`](https://youtu.be/U1suj4wuWvc)<br>

----------

<p align="center">
  <a href="https://youtu.be/U1suj4wuWvc"><img src="https://telegra.ph/file/4e8679b0d4677be9a2995.jpg" />
</p>

## Donate
- [Dana](https://wa.me/6281575886399?text=Bang+mau+donasi)
- [Gopay](https://wa.me/6281575886399?text=Bang+mau+donasi)

# Thanks to
- Irfan
- Yoga
- Riy
